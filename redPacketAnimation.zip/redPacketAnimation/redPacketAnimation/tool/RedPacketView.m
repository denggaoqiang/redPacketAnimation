//
//  RedPacketView.m
//  imageViewAnimation2
//
//  Created by style强 on 2017/12/4.
//  Copyright © 2017年 中本. All rights reserved.
//

#import "RedPacketView.h"

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height
//适配
#define ScreenAdjust(Value)  kScreenW * (Value) / 414.0

@implementation RedPacketView


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {

        //self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7];
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:frame];
        imageView.image = [UIImage imageNamed:@"背景.jpg"];
        [self insertSubview:imageView atIndex:0];
        //增加阿本ImageView
        [self addSubview:self.AbenImageView];
        //增加三个选择红包图画
        [self addSubview:self.leftPacketView];
        [self addSubview:self.centerPacketView];
        [self addSubview:self.rightPacketView];
       
        //增加红包提示
        [self addSubview:self.remindImageView];
        
         //增加金额红包
        [self addSubview:self.moneyPacketView];
        
        _cacheEmitterLayers = [NSMutableArray array];
        // CMMotionManager 初始化
        _motionMManager = [[CMMotionManager alloc] init];
        [self startMotion];
    }
    return self;
}

//增加一个点击手势
- (void)addTapGesture {
    UITapGestureRecognizer * tar = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickTheScreen)];
    tar.numberOfTapsRequired = 1;
    [self addGestureRecognizer:tar];
}

- (void)clickTheScreen {
    self.hidden = YES;
}



#pragma mark instance methods
- (void)startMotion
{
    //判断加速度是否可用
    if(_motionMManager.accelerometerAvailable)
    {
        //无论是目前的determines cmmotionmanager加速度计提供的更新。
        if (!_motionMManager.accelerometerActive)
        {
            //时间间隔
            _motionMManager.accelerometerUpdateInterval = 3.0/10.0;
            __unsafe_unretained typeof(self) weakSelf = self;
            [_motionMManager
             startAccelerometerUpdatesToQueue:[[NSOperationQueue alloc] init]
             withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) {
                 
                 //[_motionMManager stopDeviceMotionUpdates];
                 if (error)
                 {
                     NSLog(@"CoreMotion Error : %@",error);
                     [_motionMManager stopAccelerometerUpdates];
                 }
                 CGFloat a = accelerometerData.acceleration.x;
                 CGFloat b = accelerometerData.acceleration.y;
                 CGVector gravityDirection = CGVectorMake(a,-b);
                 weakSelf.gravityBehavior.gravityDirection = gravityDirection;
             }];
        }
    }
    else
    {
        NSLog(@"The accelerometer is unavailable");
    }
}

//串行
-(void)serialDrop{
    if (_isDropping) return;
    _isDropping = YES;
    dispatch_queue_t queue = dispatch_get_main_queue();
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_time_t start = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC));/**< 延迟一秒执行*/
    uint64_t interval = (uint64_t)(0.12 * NSEC_PER_SEC);
    dispatch_source_set_timer(self.timer, start, interval, 0);
    // 设置回调
    dispatch_source_set_event_handler(self.timer, ^{
        if (self.dropsArray.count == 0) return;
        NSMutableArray *currentDrops = self.dropsArray[0];
        if ([currentDrops count]) {
            if (currentDrops.count == 0) return;
            UIImageView * dropView = currentDrops[0];
            [currentDrops removeObjectAtIndex:0];
            [self addSubview:dropView];
            UIPushBehavior *pushBehavior = [[UIPushBehavior alloc] initWithItems:@[dropView] mode:UIPushBehaviorModeInstantaneous];
            [self.animator addBehavior:pushBehavior];
            //角度范围 ［0.6 1.0］
            float random = ((int)(2 + (arc4random() % (10 - 4 + 1))))*0.1;
            
            //pushDirection, 推动的方向
            //pushBehavior.pushDirection = CGVectorMake(0.5,random);
            
            if (dropView.tag == 11) {
                pushBehavior.pushDirection = CGVectorMake(-0.1,random);
            }else if (dropView.tag == 22){
                
                pushBehavior.pushDirection = CGVectorMake(0.1,random);
            }else if (dropView.tag == 33){
                
                pushBehavior.pushDirection = CGVectorMake(-0.1,random);
            }else{
                
                pushBehavior.pushDirection = CGVectorMake(0.1,random);
            }
            
            //magnitude 推动的力量
            pushBehavior.magnitude = 0.2;
            [self.gravityBehavior addItem:dropView];
            // [self.collisionBehavitor addItem:dropView];
            
            // 落到屏幕下方消失
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                //                dropView.alpha = 0;
                //                [self.gravityBehavior removeItem:dropView];
                //                [self.collisionBehavitor removeItem:dropView];
                //                [pushBehavior removeItem:dropView];
                //                [self.animator removeBehavior:pushBehavior];
                //                [dropView removeFromSuperview];
            });
            
        }else{
            //            dispatch_source_cancel(self.timer);
            //            [self.dropsArray removeObject:currentDrops];
            //            _isDropping = NO;
            //            if (self.dropsArray.count) {
            //                [self serialDrop];
            //            }
        }
        
    });
    dispatch_source_set_cancel_handler(_timer, ^{
        
    });
    //启动
    dispatch_resume(self.timer);
    
}

- (NSMutableArray *)dropWithCount:(int)count images:(NSArray *)images
{
    
    //设置爱心的个数.count  以及显示的图片位置
    NSMutableArray *viewArray = [[NSMutableArray alloc] init];
    for (int i = 0 ; i < count; i++) {
        
        UIImage *image = [images objectAtIndex:rand()%[images count]];
        UIImageView * imageView =[[UIImageView alloc ]initWithImage:image];
        //
        imageView.contentMode = UIViewContentModeCenter;
        
        if(i%4 == 1){
            imageView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2 - 75, 0);
            imageView.tag = 11;
        }else if (i%4 == 2) {
            imageView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2 - 25, 0);
            imageView.tag = 22;
        }else if(i%4 == 3){
            
            imageView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2 + 25, 0);
            imageView.tag = 33;
        }else{
            
            imageView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2 + 75, 0);
            imageView.tag = 44;
        }
        [viewArray addObject:imageView];
    }
    [self.dropsArray addObject:viewArray];
    return _dropsArray;
    
}

- (UIDynamicAnimator *)animator{
    if (!_animator) {
        _animator = [[UIDynamicAnimator alloc] initWithReferenceView:self];
        /** 重力效果*/
        self.gravityBehavior = [[UIGravityBehavior alloc] init];
        //    self.gravityBehavior.gravityDirection = CGVectorMake(0.5,0.5);
        /** 碰撞效果*/
        //        self.collisionBehavitor = [[UICollisionBehavior alloc] init];
        //        [self.collisionBehavitor setTranslatesReferenceBoundsIntoBoundary:YES];
        [_animator addBehavior:self.gravityBehavior];
        //        [_animator addBehavior:self.collisionBehavitor];
    }
    return _animator;
}

-(NSMutableArray *)dropsArray{
    if (nil == _dropsArray) {
        _dropsArray = [NSMutableArray array];
    }
    return _dropsArray;
}

-(void)start{
    _isCleared = NO;
    // UIImage *image = [UIImage imageNamed:@"20_15"];
    
    NSArray *arr = @[@"20_23",@"20_15",@"20_25",@"20_32",@"20_36",@"20_43",@"20_46",@"20_49",@"20_57",@"20_61",@"20_64",@"20_65",@"20_73",@"20_77",@"20_78",@"20_83",@"20_96",@"20_32",@"20_36",@"20_43",@"20_46",@"20_49",@"20_57",@"20_61",@"20_73",@"20_77",@"20_78",@"20_83",@"20_96",@"20_32"];
    
    NSMutableArray *picArr = [NSMutableArray array];
    
    for (int i = 0;i < arr.count; i++){
        
        UIImage *love = [UIImage imageNamed:arr[i]];
        [picArr addObject:love];
    }
    
    [self shootFrom:CGPointMake([UIScreen mainScreen].bounds.size.width / 2, 0)  Level:30 Cells:picArr];
}

- (void)shootFrom:(CGPoint)position Level:(int)level Cells:(NSArray <UIImage *>*)images; {
    if (_isCleared) return;
    CGPoint emiterPosition = position;
    // 配置发射器
    CAEmitterLayer *emitterLayer = [CAEmitterLayer layer];
    emitterLayer.emitterPosition = emiterPosition;
    //发射源的尺寸大小
    emitterLayer.emitterSize     = CGSizeMake([UIScreen mainScreen].bounds.size.width, 100);
    //发射模式
    emitterLayer.emitterMode     = kCAEmitterLayerOutline;
    //发射源的形状
    emitterLayer.emitterShape    = kCAEmitterLayerLine;
    emitterLayer.renderMode      = kCAEmitterLayerBackToFront;
    // emitterLayer.preservesDepth = 1;
    
    
    [self.layer addSublayer:emitterLayer];
    
    int index = rand()%[images count];
    CAEmitterCell *snowflake          = [CAEmitterCell emitterCell];
    snowflake.contents = [UIColor whiteColor];
    //粒子的名字
    snowflake.name                    = @"sprite";
    //粒子参数的速度乘数因子
    snowflake.birthRate               = level; //每秒生成多少个粒子
    snowflake.lifetime                = 2; //粒子存活时间
    snowflake.lifetimeRange  = 2;
    //粒子初始速度
    snowflake.velocity                = 3;
    //粒子的速度范围
    snowflake.velocityRange           = 12;
    //粒子y方向的加速度分量
    snowflake.yAcceleration           = 400;
    
    //周围发射角度
    snowflake.emissionRange           = 0.25*M_PI;
    //    snowflake.emissionLatitude = 200;
    snowflake.emissionLongitude       = 2*M_PI;//
    //子旋转角度范围
    snowflake.spin = 0.5;
    snowflake.spinRange               = 3*M_PI;
    
    snowflake.contents                = (id)[[images objectAtIndex:index] CGImage];
    snowflake.contentsScale = 0.9;
    snowflake.scale                   = 0.1;
    snowflake.scaleSpeed              = 0.1;
    
    emitterLayer.emitterCells  = [NSArray arrayWithObject:snowflake];
    [self.cacheEmitterLayers addObject:emitterLayer];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (_isCleared)return ;
        emitterLayer.birthRate = 0;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (_isCleared)return ;
            [emitterLayer removeFromSuperlayer];
            [self.cacheEmitterLayers removeObject:emitterLayer];
        });
    });
}

-(void)addSerialDrop{
    [self startMotion];
    NSArray *arr = @[@"20_09",@"20_06",@"20_03",@"20_51",@"20_96",@"20_03",@"20_93",@"20_09",@"20_03",@"20_51",@"20_96",@"20_03",@"20_09",@"20_06",@"20_03",@"20_51",@"20_96",@"20_03",@"20_93",@"20_09",@"20_03",@"20_51",@"20_96",@"20_03",];
    
    NSMutableArray *picArr = [NSMutableArray array];
    for (int i = 0;i < arr.count; i++){
        UIImage *love = [UIImage imageNamed:arr[i]];
        [picArr addObject:love];
    }
    
    [self dropWithCount:30 images:picArr];
    [self start];
    [self serialDrop];
    
}

-(void)clear{
    self.isCleared = YES;
    for (CAEmitterLayer *emitterLayer in self.cacheEmitterLayers)
    {
        [emitterLayer removeFromSuperlayer];
        emitterLayer.emitterCells = nil;
    }
    [self.cacheEmitterLayers removeAllObjects];
}

//添加落金币动画的效果
- (void) addDropEffectOfgoldCoin {
    [self addBottomAnimation];
    [self addSerialDrop];
}

////关闭用户使能 隐藏三个红包
- (void)hiddeThreePacket {
    _leftPacketView.userInteractionEnabled = NO;
    _centerPacketView.userInteractionEnabled = NO;
    _rightPacketView.userInteractionEnabled = NO;
    _remindImageView.hidden = YES;
    _leftPacketView.hidden = YES;
    _rightPacketView.hidden = YES;
    _centerPacketView.hidden = YES;
}

////打开用户使能 显示三个红包
- (void)showThreePacket {
    _leftPacketView.userInteractionEnabled = YES;
    _centerPacketView.userInteractionEnabled = YES;
    _rightPacketView.userInteractionEnabled = YES;
    _remindImageView.hidden = NO;
    _leftPacketView.hidden = NO;
    _rightPacketView.hidden = NO;
    _centerPacketView.hidden = NO;
}

//三个红包总体效果
- (void)animationThreePacketEffect {
    [self performSelector:@selector(addVerbAnimation:) withObject:@200 afterDelay:0.1];
    [self performSelector:@selector(addVerbAnimation:) withObject:@201 afterDelay:0.1];
    [self performSelector:@selector(addVerbAnimation:) withObject:@202 afterDelay:0.1];
    [self performSelector:@selector(addSkakeAnimation:) withObject:@200 afterDelay:1.0];
    [self performSelector:@selector(addSkakeAnimation:) withObject:@201 afterDelay:1.0];
    [self performSelector:@selector(addSkakeAnimation:) withObject:@202 afterDelay:1.0];
}

//三个红包翻转效果
- (void) addVerbAnimation:(id)obj {
    SelectPacketView * view = [self viewWithTag:[obj integerValue]];
    view.hidden = NO;
    [view animation1];
}

//三个红包抖动效果
- (void) addSkakeAnimation:(id)obj {
    SelectPacketView * view = [self viewWithTag:[obj integerValue]];
    view.hidden = NO;
    [view animation2];
}

//金额红包呈现
- (void) addMoneyPacketEffect {
    self.userInteractionEnabled = YES;
    _moneyPacketView.hidden = NO;
    [_moneyPacketView startAnimation];
}

//红包提示动画
- (void)addRemindImageViewAnimation {
    _remindImageView.transform = CGAffineTransformMakeScale(0.05, 0.05);
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 1.0;
        _remindImageView.transform = CGAffineTransformMakeScale(1.4, 1.4);
    }];
    //    [UIView animateWithDuration:0.1 animations:^{
    //        self.alpha = 1.0;
    //        _remindImageView.transform = CGAffineTransformMakeScale(1.4, 1.4);
    //    } completion:^(BOOL finished) {
    //        [UIView animateWithDuration:0.1 animations:^{
    //            _remindImageView.transform = CGAffineTransformMakeScale(1.3, 1.3);
    //        } completion:^(BOOL finished) {
    //            [UIView animateWithDuration:0.1 animations:^{
    //                _remindImageView.transform = CGAffineTransformMakeScale(1.4, 1.4);
    //            }];
    //        }];
    //    }];
}

//阿本动画
- (void)addBottomAnimation{
    _AbenImageView.transform = CGAffineTransformMakeScale(0.05, 0.05);
    [UIView animateWithDuration:0.5 animations:^{
        _AbenImageView.alpha = 1.0;
        _AbenImageView.transform = CGAffineTransformMakeScale(1.0, 1.0);
    }];
}

//红包赋值
- (void)putValueOfMoneyPacket:(NSString *)Value{
     _moneyPacketView.mondeyLabel.attributedText = [self changeLabelWithText:[NSString stringWithFormat:@"%@ 元",Value]];
}

-(NSMutableAttributedString*) changeLabelWithText:(NSString*)needText
{
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:needText];
    [attrString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:24] range:NSMakeRange(0,needText.length-1)];
    [attrString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(needText.length-1,1)];
    return attrString;
}

//播放音乐
- (void)playerInitialize:(NSString *)musicName AndType:(NSString *)type{
    NSString *path = [[NSBundle mainBundle] pathForResource:musicName ofType:type];
    NSURL *url = [NSURL fileURLWithPath:path];
    NSError *error = nil;
    //初始化一个音频对象，播放一首就要初始化一次，同时会把之前内容给遗弃。比如正在播放时切换一首歌，就需要重新调用下面代码。
    _player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    //一首歌播放次数：负数--无限循环，0--播放一次，1--播放2次，2--播放3此，以此类推
    _player.numberOfLoops = 0;
    //音量
    _player.volume = 0.5;
    [_player prepareToPlay];
    if (error) {
        NSLog(@"%@",error.localizedDescription);
    }
    [_player play];
}

- (UIImageView *)AbenImageView {
    if (!_AbenImageView) {
        _AbenImageView = [[UIImageView alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - ScreenAdjust(300), [UIScreen mainScreen].bounds.size.height -  ScreenAdjust(300) * 0.81, ScreenAdjust(300), ScreenAdjust(300) * 0.81)];
        _AbenImageView.alpha = 0.0;
        [_AbenImageView setImage:[UIImage imageNamed:@"Aben.png"]];
    }
    return _AbenImageView;
}

- (SelectPacketView *)leftPacketView {
    if (!_leftPacketView) {
        _leftPacketView = [[SelectPacketView alloc] initWithFrame:CGRectMake(10, [UIScreen mainScreen].bounds.size.height * 0.3, ([UIScreen mainScreen].bounds.size.width - 60) / 3, ([UIScreen mainScreen].bounds.size.width - 60) / 3 * 1.37 )];
        _leftPacketView.tag = 200;
        _leftPacketView.hidden = YES;
    }
    return _leftPacketView;
}

- (SelectPacketView *)centerPacketView {
    if (!_centerPacketView) {
        _centerPacketView = [[SelectPacketView alloc] initWithFrame:CGRectMake(30 + ([UIScreen mainScreen].bounds.size.width - 60) / 3, [UIScreen mainScreen].bounds.size.height * 0.3, ([UIScreen mainScreen].bounds.size.width - 60) / 3, ([UIScreen mainScreen].bounds.size.width - 60) / 3 * 1.37 )];
        _centerPacketView.tag = 201;
        _centerPacketView.hidden = YES;
    }
    return _centerPacketView;
}

- (SelectPacketView *)rightPacketView {
    if (!_rightPacketView) {
        _rightPacketView = [[SelectPacketView alloc] initWithFrame:CGRectMake(50 +([UIScreen mainScreen].bounds.size.width - 60) * 2 / 3, [UIScreen mainScreen].bounds.size.height * 0.3, ([UIScreen mainScreen].bounds.size.width - 60) / 3, ([UIScreen mainScreen].bounds.size.width - 60) / 3 * 1.37 )];
        _rightPacketView.tag = 202;
        _rightPacketView.hidden = YES;
    }
    return _rightPacketView;
}

- (UIView *)moneyPacketView {
    if (!_moneyPacketView) {
        _moneyPacketView = [[MoneyPacketView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width * 0.45,[UIScreen mainScreen].bounds.size.width * 0.6)];
        _moneyPacketView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2, [UIScreen mainScreen].bounds.size.height / 2 - 30);
        _moneyPacketView.alpha = 0.0;
        _moneyPacketView.hidden = YES;
    }
    return _moneyPacketView;
}

- (UIImageView *)remindImageView {
    if (!_remindImageView) {
        _remindImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 150, 27)];
        _remindImageView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2, [UIScreen mainScreen].bounds.size.height * 0.6);
        _remindImageView.image = [UIImage imageNamed:@"remindLabel.png"];
        _remindImageView.alpha = 1;
    }
    return _remindImageView;
}

@end
