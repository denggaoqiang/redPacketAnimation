//
//  SelectPacketView.h
//  imageViewAnimation2
//
//  Created by 中本 on 2017/12/1.
//  Copyright © 2017年 中本. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SelectPacketViewDelegate<NSObject>
@required
-(void)clickThePacketImageView:(NSInteger)tag;
@end

@interface SelectPacketView : UIView
@property (nonatomic,strong) UIImageView * packetImageView;
@property (nonatomic,weak) id <SelectPacketViewDelegate> delegate;
- (void)animation1;
- (void)animation2;
@end
