//
//  RedPacketView.h
//  imageViewAnimation2
//
//  Created by style强 on 2017/12/4.
//  Copyright © 2017年 中本. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>
#import "SelectPacketView.h"
#import "MoneyPacketView.h"
#import <AVFoundation/AVFoundation.h>

@interface RedPacketView : UIView <UIAccelerometerDelegate>

@property (nonatomic , strong) UIDynamicAnimator        * animator;
@property (nonatomic , strong) UIGravityBehavior        * gravityBehavior;
//@property (nonatomic , strong) UICollisionBehavior      * collisionBehavitor;
@property (nonatomic , strong) UIDynamicItemBehavior    * itemBehavitor;
@property (nonatomic, strong)  CMMotionManager * motionMManager;
@property (strong,nonatomic)   NSMutableArray *dropsArray;
@property (strong,nonatomic) UIImageView *leftShoot;
@property (strong,nonatomic) UIImageView *rightShoot;

@property (nonatomic, strong) dispatch_source_t timer;

@property (assign,nonatomic) BOOL isDropping;

@property (assign,nonatomic) int page;

@property (assign,nonatomic) BOOL               isCleared;
@property (strong,nonatomic) NSMutableArray     *cacheEmitterLayers;

//半透明层
@property (strong,nonatomic) UIImageView *AbenImageView; //aben图标
@property (strong,nonatomic) SelectPacketView * leftPacketView;
@property (strong,nonatomic) SelectPacketView * centerPacketView;
@property (strong,nonatomic) SelectPacketView * rightPacketView;
@property (nonatomic,strong) MoneyPacketView * moneyPacketView;
@property (nonatomic,strong) AVAudioPlayer * player;
@property (nonatomic,strong) UIImageView * remindImageView;

- (void) addDropEffectOfgoldCoin;
- (void) animationThreePacketEffect;
- (void) addMoneyPacketEffect;
- (void) hiddeThreePacket;
- (void) showThreePacket;
- (void) addTapGesture;
- (void) putValueOfMoneyPacket:(NSString *)Value;
- (void) playerInitialize:(NSString *)musicName AndType:(NSString *)type;
- (void) addRemindImageViewAnimation;
@end
