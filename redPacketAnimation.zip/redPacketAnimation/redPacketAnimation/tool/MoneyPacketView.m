//
//  MoneyPacketView.m
//  AnimationView
//
//  Created by style强 on 2017/12/2.
//  Copyright © 2017年 style强. All rights reserved.
//

#import "MoneyPacketView.h"
#import "Masonry.h"

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height
//适配
#define ScreenAdjust(Value)  kScreenW * (Value) / 414.0

@implementation MoneyPacketView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        _imageView.image = [UIImage imageNamed:@"活动红包.jpg"];
        [self addSubview:_imageView];
        _mondeyLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 30)];
        _mondeyLabel.center = CGPointMake(frame.size.width / 2, frame.size.height / 2);
        _mondeyLabel.textAlignment = NSTextAlignmentCenter;
        [_mondeyLabel setFont:[UIFont systemFontOfSize:ScreenAdjust(32)]];
        _mondeyLabel.textColor = [UIColor yellowColor];
        [self addSubview:_mondeyLabel];
        
        _detailBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _detailBtn.frame = CGRectMake(self.frame.size.width * 0.256,self.frame.size.height * 0.76 ,self.frame.size.width * 0.5, self.frame.size.height * 0.1);
        [_detailBtn setBackgroundImage:[UIImage imageNamed:@"checkPacket.png"] forState:UIControlStateNormal];
        [_detailBtn addTarget:self action:@selector(clickTheBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_detailBtn];
    }
    return self;
}

- (void) startAnimation {
    self.transform = CGAffineTransformMakeScale(0.05, 0.05);
    [UIView animateWithDuration:0.1 animations:^{
        self.alpha = 1.0;
        self.transform = CGAffineTransformMakeScale(1.4, 1.4);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.1 animations:^{
            self.transform = CGAffineTransformMakeScale(1.3, 1.3);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.1 animations:^{
                self.transform = CGAffineTransformMakeScale(1.4, 1.4);
            }];
        }];
    }];
}

- (void)clickTheBtn:(id)sender{
    if (_delegate && [_delegate respondsToSelector:@selector(clickThePacketDetail)]) {
        [_delegate clickThePacketDetail];
    }
}

@end
