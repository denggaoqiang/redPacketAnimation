//
//  MoneyPacketView.h
//  AnimationView
//
//  Created by style强 on 2017/12/2.
//  Copyright © 2017年 style强. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol MoneypacketViewDelegate<NSObject>
@required
-(void)clickThePacketDetail;
@end

@interface MoneyPacketView : UIView

@property (nonatomic,strong)UIImageView * imageView;

@property (nonatomic,strong) UILabel * mondeyLabel;

@property (nonatomic,strong) UIButton * detailBtn;

@property (nonatomic,weak) id<MoneypacketViewDelegate> delegate;
- (void) startAnimation;

@end
