//
//  SelectPacketView.m
//  imageViewAnimation2
//
//  Created by 中本 on 2017/12/1.
//  Copyright © 2017年 中本. All rights reserved.
//

#import "SelectPacketView.h"

@implementation SelectPacketView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = YES;
        _packetImageView = [[UIImageView alloc] initWithFrame:self.bounds];
        _packetImageView.image = [UIImage imageNamed:@"红包.png"];
        [self addSubview:_packetImageView];
        UITapGestureRecognizer * tgr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickTheBtn)];
        tgr.numberOfTapsRequired = 1;
        [self addGestureRecognizer:tgr];
    }
    return self;
}

- (void)animation1 {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationTransition: UIViewAnimationTransitionFlipFromLeft  forView:self cache:YES];
    [UIView commitAnimations];
}

- (void)animation2 {
    CABasicAnimation* shake = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    //设置抖动幅度
    shake.fromValue = [NSNumber numberWithFloat:-0.1];
    shake.toValue = [NSNumber numberWithFloat:+0.1];
    shake.duration = 0.1;
    shake.autoreverses = YES; //是否重复
    shake.repeatCount = 3;
    [self.packetImageView.layer addAnimation:shake forKey:@"imageView"];
}

- (void)clickTheBtn {
    if (_delegate && [_delegate respondsToSelector:@selector(clickThePacketImageView:)]) {
        [_delegate clickThePacketImageView:self.tag];
    }
}

@end
