//
//  ViewController.m
//  redPacketAnimation
//
//  Created by 中本 on 2017/12/30.
//  Copyright © 2017年 中本. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)clickTheBtn:(UIButton *)btn {
    SecondViewController * sec = [[SecondViewController alloc] init];
    [self.navigationController pushViewController:sec animated:NO];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(100, 100, 100, 60);
    button.backgroundColor = [UIColor cyanColor];
    [button setBackgroundImage:[UIImage imageNamed:@"qwer.png"] forState:UIControlStateNormal];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(clickTheBtn:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
