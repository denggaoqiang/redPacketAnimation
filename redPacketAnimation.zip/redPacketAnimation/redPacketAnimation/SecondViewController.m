//
//  SecondViewController.m
//  redPacketAnimation
//
//  Created by 中本 on 2017/12/30.
//  Copyright © 2017年 中本. All rights reserved.
//

#import "SecondViewController.h"
#import "RedPacketView.h"

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height

@interface SecondViewController ()<SelectPacketViewDelegate,MoneypacketViewDelegate>

@property (nonatomic,strong) RedPacketView * redPacketView;
@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self initRedB];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initRedB{
    
    _redPacketView = [[RedPacketView alloc] initWithFrame:CGRectMake(0, 0,kScreenW ,kScreenH )];
    //设置代理
    _redPacketView.moneyPacketView.delegate = self;
    _redPacketView.leftPacketView.delegate = self;
    _redPacketView.centerPacketView.delegate = self;
    _redPacketView.rightPacketView.delegate = self;
    [[UIApplication sharedApplication].keyWindow addSubview:_redPacketView];
    
    //添加文字提示
    [_redPacketView addRemindImageViewAnimation];
    //添加落金币动画
    [_redPacketView addDropEffectOfgoldCoin];
    //播放背景音乐
    [self.redPacketView playerInitialize:@"packetMusic" AndType:@"wav"];
    //UIView的翻转和震动
    [self.redPacketView performSelector:@selector(animationThreePacketEffect) withObject:nil afterDelay:1.0];
}

#pragma --PacketViewDelegate
- (void)clickThePacketImageView:(NSInteger)tag {
    
    [self.redPacketView hiddeThreePacket];
    [_redPacketView addTapGesture];
    [_redPacketView putValueOfMoneyPacket:@"88.88"];
    [_redPacketView addMoneyPacketEffect];
}

#pragma -- MoneypacketViewDelegate
- (void)clickThePacketDetail {
    NSLog(@"点击了查看详情");
}

- (void)putValueOfMoneyPacket:(NSString *)Value{
    _redPacketView.moneyPacketView.mondeyLabel.attributedText = [self changeLabelWithText:[NSString stringWithFormat:@"%@ 元",Value]];
}

-(NSMutableAttributedString*) changeLabelWithText:(NSString*)needText
{
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:needText];
    [attrString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:24] range:NSMakeRange(0,needText.length-1)];
    [attrString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(needText.length-1,1)];
    return attrString;
}

@end
